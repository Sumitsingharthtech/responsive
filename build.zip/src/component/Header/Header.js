import React from 'react'
import './Header.css';
// import {BsArrowLeftShort } from "react-icons/bs";
const Header = () => {
    return (
        <>
              <div className="black"> </div>

<div className="icon">
  {/* <button className="btn-1">  <BsArrowLeftShort /> Back </button> */}
  
  <h4 > <span>home</span>centre </h4>
</div>
        </>
    )
}

export default Header
