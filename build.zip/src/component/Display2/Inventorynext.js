import React from 'react'
import './Inventorynext.css'

const Inventorynext = () => {
    return (
        <>
               <div className='inventorynext'>
                    <div className='heading'>
                        <p className='head'>Buddy Store List</p>
                        <p className='head-a'>Qty</p>
                        </div> 
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div> 
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='heading'>
                            <input className='check' type='radio'/>
                        <p className='buddy'>HC - Global Fesval City</p>
                        <p className='qty'>100</p>
                        </div>
                        <div className='confirm'>
                        <button>CONFIRM</button>
                        </div>
                        
                        </div> 
        </>
    )
}

export default Inventorynext
