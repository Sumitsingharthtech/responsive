import React from 'react'
import './Footer.css';

const Footer = () => {
    return (
        <>
            <div className='footer' > 
            <h1>d</h1>
             </div>
        </>
    )
}

export default Footer
